-- Migration: blog_posts table for admin-managed blog content.
-- Pattern mirrors public.bookings (init_bookings.sql + fix_bookings_rls.sql):
--   * anon SELECT is allowed for published posts only (active = true) so the
--     public website can render them without authentication.
--   * authenticated (admin) gets full read/write — drafts visible to admins only.
--   * Re-runnable: CREATE IF NOT EXISTS + INSERT ON CONFLICT DO NOTHING.
--
-- Apply: Supabase Dashboard → SQL Editor → New query → paste this file → Run.

create table if not exists public.blog_posts (
  id            text primary key,
  slug          text not null unique,
  title         text not null,
  excerpt       text default '',
  category      text default 'Insights',
  read_minutes  integer default 5,
  hero_image    text default '',
  hero_alt      text default '',
  publish_date  date,
  author        text default 'Kanaan Editorial',
  tldr          text default '',
  lede          text default '',
  body_html     text default '',
  active        boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- Fast lookup by slug (used by the single-post page) and by (active, date)
-- for the index page sort.
create index if not exists idx_blog_posts_slug         on public.blog_posts (slug);
create index if not exists idx_blog_posts_active_date  on public.blog_posts (active, publish_date desc);

-- Auto-bump updated_at on every UPDATE.
create or replace function public.blog_posts_set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_blog_posts_updated_at on public.blog_posts;
create trigger trg_blog_posts_updated_at
  before update on public.blog_posts
  for each row execute function public.blog_posts_set_updated_at();

-- RLS — same pattern as bookings.
alter table public.blog_posts enable row level security;

drop policy if exists "public read published" on public.blog_posts;
drop policy if exists "auth read all"          on public.blog_posts;
drop policy if exists "auth insert"            on public.blog_posts;
drop policy if exists "auth update"            on public.blog_posts;
drop policy if exists "auth delete"            on public.blog_posts;

-- Anyone (including unauthenticated site visitors) can read PUBLISHED posts.
create policy "public read published"
  on public.blog_posts
  for select
  to anon, authenticated
  using (active = true);

-- Signed-in admins can read every row (including drafts).
create policy "auth read all"
  on public.blog_posts
  for select
  to authenticated
  using (true);

-- Signed-in admins can insert/update/delete.
create policy "auth insert"
  on public.blog_posts
  for insert
  to authenticated
  with check (true);

create policy "auth update"
  on public.blog_posts
  for update
  to authenticated
  using (true)
  with check (true);

create policy "auth delete"
  on public.blog_posts
  for delete
  to authenticated
  using (true);

-- Seed with the 7 posts currently in content/blog.json.
-- ON CONFLICT keeps the migration re-runnable without overwriting admin edits.
insert into public.blog_posts
  (id, slug, title, excerpt, category, read_minutes, hero_image, hero_alt, publish_date, author, tldr, lede, body_html, active)
values
  ('how-to-talk-to-your-barber', 'how-to-talk-to-your-barber', 'How to talk to your barber.', 'The 30-second consultation that gets you the haircut you actually wanted.', 'Grooming', 4, '/assets/img/photos/service-hair-brand-wall-1600.webp', 'Master barber chair and product wall at Kanaan', '2026-05-15', 'Master Barber’s Desk', 'Bring a photo. Use clipper numbers (1-8) for the sides — not "short." Say what you don’t want, not just what you want. Mention your hair pattern (cowlicks, double crown). Be specific about how long you want the cut to last.', 'Most miscommunication between a man and his barber happens in the first 60 seconds. The fix isn’t to use barber jargon — it’s to be specific about three things.', '<h2>1. Bring a photo</h2><p>This is the single most useful thing you can do. Even if your hair will never look exactly like the photo (it won’t — different hair, different face, different lighting), the photo tells your barber the <em>shape</em> you’re aiming for. "Short on the sides, longer on top" describes 70% of men’s haircuts.</p><p>If you don’t have a photo, point at the barber’s reference book or open Instagram in the chair. No shame in it.</p><h2>2. Use clipper numbers for the sides</h2><p>Barbers think in clipper guard sizes (1 to 8). "Short" means nothing — to one barber it’s a #2, to another a #4. The difference is significant on the day-of look.</p><ul><li><strong>#1</strong> — very close, almost shaved</li><li><strong>#2</strong> — short fade, visible scalp through hair</li><li><strong>#3</strong> — classic short side, the most common ask</li><li><strong>#4</strong> — short but blended, not stark</li><li><strong>#5+</strong> — longer side, scissor finish often better</li></ul><p>If you don’t know the number, ask the barber what you had last time and adjust from there.</p><h2>3. Say what you don’t want</h2><p>"Don’t fade it all the way down" is more useful than "medium fade." "Leave some weight in the back" is clearer than "not too short."</p><p>The barber’s job is to navigate between your description and what the hair will actually do. Negative descriptions ("not this") are sometimes more informative than positive ones.</p><h2>4. Mention your hair pattern</h2><p>If you have a double crown, a strong cowlick, or a part that won’t behave, tell us upfront. We’ll see it eventually, but knowing in advance changes how we plan the cut — especially the top length.</p><h2>5. Tell us when your next visit is</h2><p>"I’m coming back in 3 weeks" lets us cut for that specific window. "I want this to last 6 weeks" means we leave more length so it grows out cleanly. Without that information, we default to the average — which may be the wrong call for you.</p><h2>The follow-up</h2><p>If something didn’t work, tell us at the next visit — or before, on <a href="https://wa.me/971505556795" class="text-gold">WhatsApp</a>. We’d rather you tell us "it was too short last time" than try to guess what you want.</p><p><a href="/book?service=hair-beard" class="text-gold">Book a haircut</a> at any Kanaan branch.</p>', true),
  ('haircut-frequency', 'haircut-frequency', 'How often should a man get a haircut?', 'Every 3 weeks? Every 6 weeks? Depends on what you want your hair to do.', 'Grooming', 4, '/assets/img/photos/service-hair-barber-stations-1600.webp', 'Inside a Kanaan barber room with master barber stations', '2026-05-08', 'Master Barber’s Desk', 'Skin fade or tight taper: 2-3 weeks. Short crop: 3-4 weeks. Mid-length textured: 5-6 weeks. Growing out / long hair: 6-8 weeks (still needs trims). Beards: every 3-4 weeks. If it’s been over 3 months, book a "shape-up" instead of a full cut.', 'It’s the question every man asks his barber within 90 seconds of sitting down. The answer is less about a calendar and more about what your hair is doing — and what you want it to do next.', '<h2>The honest answer</h2><p>If you keep a short, defined cut — fade, taper, sharp side part, anything where the lines need to read clean — you’ll feel it grow out in week three. Most men in this category settle on a 3-week rhythm. By week four it’s looking shaggy under a cap and your barber spends half the session catching up.</p><p>If your style is a longer crop or textured top, you can stretch to 5-6 weeks before the shape starts to fight you. Past that, the cut isn’t growing out — it’s becoming a different cut.</p><h2>Five honest categories</h2><h3>Buzz, skin fade, or tight taper</h3><p>Every 2-3 weeks. The whole point of these cuts is the contrast at the line. The moment it blurs, the cut looks unintentional.</p><h3>Short crop with definition</h3><p>Every 3-4 weeks. The top holds for longer; the sides give it away first.</p><h3>Mid-length, textured, or messy on purpose</h3><p>Every 5-6 weeks. Forgiving cuts that look better with a little weight on top.</p><h3>Growing out / long hair</h3><p>Every 6-8 weeks. Counterintuitive — you still need a trim. Without one, the ends split and the whole length starts to look thin.</p><h3>The "I’ll just deal with it later" approach</h3><p>Don’t. Three months between visits means your barber is rebuilding the cut from scratch every time, and you never get to enjoy the version that actually works.</p><h2>Beards follow a different rhythm</h2><p>Most beards need a maintenance trim every 3-4 weeks. The shape blurs faster than head hair, especially around the cheek line and neckline. A 15-minute beard sculpt at Kanaan starts at 35 AED.</p><h2>If you’re between visits</h2><p>If you can’t get to Kanaan for a full cut, book a 30-minute shape-up — cleans up the perimeter (neckline, sides, around the ears) without changing the cut. Buys you another two weeks easily.</p><p><a href="/book?service=hair-beard" class="text-gold">Book a haircut</a> or <a href="/branches" class="text-gold">find your nearest Kanaan branch</a>.</p>', true),
  ('choosing-your-massage', 'choosing-your-massage', 'Choosing your massage.', 'Swedish, deep tissue, hot stone, sports recovery. Which one your body actually needs.', 'Spa', 5, '/assets/img/photos/service-massage-tools-1600.webp', 'Massage tools and oils laid out at Kanaan Baniyas Spa', '2026-04-25', 'Kanaan Editorial', 'Swedish = recovery and relaxation. Deep tissue = chronic tension. Hot stone = stress relief in cold/AC environments. Sports = post-workout recovery. Hot herbal = aromatic ritual. All five at 150 AED for 60 minutes at any Kanaan branch with a massage room.', 'Most men book a massage by guessing. The names sound similar enough that picking feels arbitrary. It isn’t. Each style is designed for a different body and a different week.', '<h2>Swedish — the all-rounder</h2><p>Long, flowing strokes at moderate pressure. The default choice for a reason — it covers most of what people want from a massage: tension release, circulation, parasympathetic-nervous-system reset. If you don’t have a specific complaint and just want to unwind, this is the one.</p><p><strong>Choose if:</strong> first-time massage, general stress, want to relax without thinking too hard about it.</p><h2>Deep tissue — for chronic tightness</h2><p>Slower pressure, focused on specific muscle groups (shoulders, lower back, hamstrings). The therapist holds pressure on knots until they release. It can be uncomfortable in the moment; it’s not supposed to hurt, but it’s not Swedish either.</p><p><strong>Choose if:</strong> desk job, recurring back tension, neck stiffness, posture-related issues.<br><strong>Skip if:</strong> you’re in the mood to relax — this requires you to breathe through pressure points.</p><h2>Hot stone — temperature does half the work</h2><p>Heated basalt stones placed along the spine and used as massage tools. Heat penetrates deeper than hands can, which means less pressure for the same release. Excellent in winter and over-AC’d offices.</p><p><strong>Choose if:</strong> you find regular massage too rough, cold-prone, want maximum relaxation.</p><h2>Sports recovery — for the gym crowd</h2><p>Combines compression, stretching, and friction over muscle groups that have been worked. Best done within 48 hours of a hard session.</p><p><strong>Choose if:</strong> you train consistently and want recovery acceleration, not relaxation.</p><h2>Hot herbal — the aromatic version</h2><p>Muslin compresses filled with herbs (lemongrass, ginger, eucalyptus) are steamed and pressed along the body. Therapeutic and aromatic in equal measure.</p><p><strong>Choose if:</strong> you want the experience, the smell, the ritual. Excellent introduction if you’re not sure spa is for you.</p><h2>How long</h2><p>60 minutes is the standard and what most men should book. 90 minutes if you have specific tension that needs working through. 30 minutes if it’s a focused area only — head and shoulders after a long flight, for example.</p><p><a href="/book?service=massage" class="text-gold">Book a massage</a> — all five styles available at Baniyas Spa, Khalifa City, Al Ain, Khalidiya, Old Shahamah, and VIP Muroor. 150 AED for 60 minutes.</p>', true),
  ('choosing-the-right-facial', 'choosing-the-right-facial', 'Choosing the right facial for UAE skin.', 'Choosing between hydra, signature, and anti-fatigue.', 'Skin', 5, '/assets/img/photos/service-facial-candlelit-1600.webp', 'Candlelit facial treatment room at Kanaan', '2026-04-18', 'Kanaan Editorial', 'Hydra-facial = dehydrated, AC-burned skin. Signature = a maintenance treatment that suits most men. Anti-fatigue = under-eye puffiness, late nights, screen exhaustion. Anti-ageing = first lines, lost firmness. Pick by what your skin is doing right now, not your age.', 'Most clients arrive with the same question: "what''s the difference between these facials?" Here''s the honest version, from the perspective of the people who actually do them.', '<h2>Hydra-Facial — for the AC-burned</h2><p>If your skin feels tight by 4pm, looks dull under office light, and shows fine flakes around the nostrils, you''re dehydrated, not aged. The hydra-facial uses a vortex tool to flush impurities and infuse hyaluronic acid serum at the same time. The result is visible immediately. Best every 4–6 weeks.</p><h2>Signature Facial — the maintenance choice</h2><p>Cleanse, exfoliate, mask, massage, finish. Done well, it covers most needs and works on every skin type. If you don''t have a specific concern, this is the one to do. 75 minutes; deserves the time it takes.</p><h2>Anti-Fatigue Facial — for late nights</h2><p>Cold-stone massage around the eyes, caffeine serum, lymphatic drainage along the jaw. Designed to depuff and reduce dark circles in a single sitting. Best before an event or after a heavy travel week.</p><h2>Anti-Ageing Facial — for first lines</h2><p>If you''re noticing fine lines around the eyes or a softer jawline, the anti-ageing protocol uses peptide serum, micro-current, and a firming mask. Not magic, but the difference is real if you keep it monthly.</p><h2>Book the right one</h2><p>If you''re unsure, the signature is the safest pick — your therapist will adjust within the session. <a href="/book?service=facial-skin-care" class="text-gold">Book a facial</a>.</p>', true),
  ('pre-wedding-grooming', 'pre-wedding-grooming', 'A 14-day pre-wedding grooming plan.', 'Two weeks out from the wedding — the grooming schedule that means you look right in every photo.', 'Editorial', 6, '/assets/img/photos/arch-staircase-lemon-1600.webp', 'Editorial interior at Kanaan — marble staircase, lemon-gold light', '2026-04-12', 'Kanaan Editorial', 'Day 14: keratin + first facial. Day 10: haircut (it grows in by the day). Day 7: full grooming reset. Day 3: second facial. Day 2: beard shape + manicure + pedicure. Wedding morning: hot-towel shave only. Book the same barber and therapist across all sessions for consistency.', 'Wedding photos last. The way you look in the close-ups will not be a thing you reshoot. A 14-day plan is the single highest-leverage prep most grooms skip — and the difference is unmistakable in print.', '<h2>Why 14 days, not 14 hours</h2><p>Skin needs time to settle after a facial. Hair needs time to grow into a cut. A keratin treatment looks best a week in. Doing everything in the 48 hours before the wedding gives you the opposite of what you want: red skin, a too-fresh cut, products still being absorbed. The plan below sequences each step at the right interval.</p><h2>Day 14 — the foundation</h2><p>If your hair takes treatment, this is when to do <a href="/services/hair-treatment" class="text-gold">keratin</a>. It softens texture and adds shine — by the wedding day it’s settled and looks natural in photos.</p><p>Book your first <a href="/services/facial-skin-care" class="text-gold">facial</a> the same week. Pick a Hydra-Facial if your skin tends to look dull, Signature if you just want a general reset. The reason for booking now: your skin recovers and you’ll see what your face actually looks like clean for the next planning step.</p><h2>Day 10 — the haircut</h2><p>This is when the cut goes in. By the wedding day it will have grown out by ~2mm, which is exactly where most cuts look best — not still-from-the-chair fresh, not shaggy. Tell your barber it’s for a wedding and ask them to err on the conservative side of length.</p><h2>Day 7 — the full reset</h2><p>One week out, book a complete grooming session: haircut touch-up if needed, beard shape, facial, manicure. The point of this session is to identify anything that needs attention. Dry patches you didn’t notice. A scar healing slowly. The barber and therapist will tell you what to do at home for the next 6 days.</p><h2>Day 3 — second facial</h2><p>A second facial 3 days out gives the skin one more chance to look its best on the day. Skip if your skin is sensitive or has reacted to anything in the previous week.</p><h2>Day 2 — shape-up + nails</h2><p>Beard sculpt, hairline shape-up, full manicure and pedicure. Nails matter in the ring-exchange close-up. Don’t trim too aggressively — leave a sliver of white.</p><h2>Wedding morning — hot-towel shave</h2><p>One service only: a proper hot-towel shave (or a beard final-touch if you wear one). Skin will look its best 60-90 minutes after, and you avoid the unfocused look of doing too much same-day.</p><h2>Tell us in advance</h2><p>Book early — we can dedicate the same barber and therapist across all 14 days so the plan is consistent. WhatsApp us at <a href="https://wa.me/971505556795" class="text-gold">+971 50 555 6795</a> and ask for the pre-wedding programme.</p>', true),
  ('beard-care-abu-dhabi', 'beard-care-abu-dhabi', 'Beard care in Abu Dhabi''s climate.', 'Heat, dust, AC. How to keep your beard healthy through it all.', 'Grooming', 5, '/assets/img/photos/service-hair-brand-wall-1600.webp', 'Beard grooming station with professional product wall at Kanaan', '2026-04-02', 'Kanaan Editorial', 'Wash beard 3x/week with sulfate-free shampoo. Oil daily with argan or jojoba. Trim shape every 3 weeks. Drink water. Avoid alcohol-based products. Book a beard sculpt for the first cut to set a clean line.', 'A beard in Abu Dhabi has a harder job than a beard in Madrid. Our climate cycles through three things at once — outside heat, dehumidified AC indoors, and fine desert dust — all of which strip oils, irritate skin underneath, and leave the beard looking rougher than its owner. Here is what our master barbers actually recommend, simplified.', '<h2>Wash less, condition more</h2><p>Most men in Abu Dhabi wash their beard daily. The combination of dust on the skin and sweat under the hair seems to demand it. But every wash strips the natural oils — and the AC indoors already dries you out. The compromise: wash 2–3 times a week with a sulfate-free shampoo, and condition every time. A 60-second beard mask once a week makes a measurable difference.</p><h2>Oil it, every day</h2><p>Beard oil is not a marketing invention. Skin under a beard dries out faster than skin elsewhere, and the hair itself loses lustre when its cuticle goes rough. A few drops of argan or jojoba oil, worked in with fingertips down to the skin, restores both. Do it once in the morning, ideally after a shower while the pores are still open.</p><h2>Trim the shape, not the length</h2><p>The single biggest mistake men make: trimming all over to keep length down, instead of trimming the shape regularly. Beards in dry climates split at the ends faster. A simple maintenance trim keeps the shape. We do this in 15 minutes — a beard sculpt is 60 AED at most Kanaan branches.</p><h2>Hydrate from inside</h2><p>This sounds obvious until you realise how many men spend an entire workday on coffee. Water matters. The skin under a beard tells on you faster than face skin.</p><h2>Book a beard sculpt at Kanaan</h2><p>If your beard hasn''t had a professional shape in over a month, that''s the first move. We work with the natural growth pattern rather than against it. <a href="/book?service=hair-beard" class="text-gold">Book a beard sculpt</a>.</p>', true),
  ('moroccan-bath-guide', 'moroccan-bath-guide', 'A Moroccan bath, properly explained.', 'What it is, why men love it, and how to get the most from your visit.', 'Spa Craft', 6, '/assets/img/photos/service-moroccan-shower-1600.webp', 'Steam and stone of the Moroccan hammam at Kanaan Baniyas Spa', '2026-03-15', 'Kanaan Editorial', 'A Moroccan bath is a 4-step ritual: 12-15 min steam, black-soap cleanse, kessa-glove exfoliation, and a hydrating mask + argan-oil finish. Best every 4-6 weeks. Available at 6 Kanaan branches for 130-300 AED (Normal / Special / Royal tiers).', 'If you''ve never had a Moroccan bath, the first time can feel unfamiliar. The room is hotter than expected. There is steam. There is black soap. There is a glove that looks more like a kitchen tool than a spa one. And there is a person — usually one you''ve never met — who treats your skin with a gentle but committed firmness. Then you leave, somehow lighter, and you understand why men have been coming back for centuries.', '<p>Here is what''s actually happening, and how to get the most from a visit at Kanaan.</p>
<h2>The four steps</h2>
<h3>1. Steam (12–15 minutes)</h3>
<p>You start in our hammam — a steam room kept around 40°C with high humidity. The job here is simple: open the pores. Your therapist will check on you and bring water; sit, breathe slowly, and let your body soften. By the time the steam ends, your skin will release impurities easily.</p>
<h3>2. Black soap cleanse</h3>
<p>Beldi black soap is a paste made from olive oil and macerated olives. It''s deeply purifying without being harsh. Your therapist applies it to your whole body and lets it sit for 5–10 minutes. It tightens slightly as it works.</p>
<h3>3. Kessa exfoliation</h3>
<p>This is the heart of the ritual. The kessa glove is intentionally rough — it removes the layer of dead skin the steam and soap have loosened. Done properly, it''s brisk but never painful. You will see the result come off your skin. It is honest evidence that the work matters.</p>
<h3>4. Mask, rinse, finish</h3>
<p>A hydrating clay mask (we use ghassoul) is applied to lock moisture back in. Final rinse, towel dry, and a finish with argan oil. Your skin will feel — there''s no other way to say it — new.</p>
<h2>How often is right?</h2>
<p>For most men, every 4–6 weeks is the sweet spot. Your skin''s natural cell turnover is roughly 28 days; doing it more often than that doesn''t add benefit. Doing it less than once a quarter, you start to feel the difference between visits.</p>
<h2>What to bring (and not bring)</h2>
<p>Disposable underwear and a robe are provided. Bring nothing — leave watches, jewellery, phones in the locker. Hydrate well in the hour before your appointment. Don''t shave the same day; the skin will be sensitive after the kessa.</p>
<h2>Where to book</h2>
<p>The Moroccan bath is offered at six Kanaan branches: <a href="/branches/baniyas-spa" class="text-gold">Baniyas Spa</a> and <a href="/branches/khalifa-city" class="text-gold">Khalifa City</a> (our flagship spa houses), plus <a href="/branches/al-ain" class="text-gold">Al Ain</a>, <a href="/branches/khalidiya" class="text-gold">Khalidiya</a>, <a href="/branches/old-shahamah" class="text-gold">Old Shahamah</a>, and <a href="/branches/vip-muroor" class="text-gold">VIP Muroor</a>. Three tiers: Normal 130 AED, Special 180 AED, Royal 300 AED.</p>
<p><a href="/book?service=moroccan-bath" class="btn">Book a Moroccan Bath</a></p>', true)
on conflict (id) do nothing;
